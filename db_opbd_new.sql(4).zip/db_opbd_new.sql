-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 21, 2012 at 02:52 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_opbd_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_email_address` varchar(100) NOT NULL,
  `admin_password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `admin_name`, `admin_email_address`, `admin_password`) VALUES
(1, 'Saahil Alam Talha', 'saahil@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `category_id` int(2) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `category_description` text NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`) VALUES
(1, 'Laptop', '<p>\r\n	This is laptop category</p>\r\n'),
(2, 'Tv', '<p>\r\n	This is Tv category</p>\r\n'),
(3, 'Desktop', '<p>\r\n	This is Desktop Category</p>\r\n'),
(4, 'iPhone', '<p>\r\n	This is iPhone category</p>\r\n'),
(5, 'Camera', '<p>\r\n	this is camera category</p>\r\n'),
(6, 'Mobile', '<p>\r\n	this is mobile category</p>\r\n'),
(7, 'Pen Drive', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_id` int(3) NOT NULL AUTO_INCREMENT,
  `user_id` int(3) NOT NULL,
  `shipping_id` int(3) NOT NULL,
  `payment_id` int(3) NOT NULL,
  `order_total` double NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `user_id`, `shipping_id`, `payment_id`, `order_total`, `payment_status`) VALUES
(1, 14, 2, 0, 59000, 'cash on delevary'),
(2, 14, 2, 0, 130000, 'cash on delevary');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE IF NOT EXISTS `tbl_order_details` (
  `order_detail_id` int(3) NOT NULL AUTO_INCREMENT,
  `order_id` int(3) NOT NULL,
  `product_id` int(3) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` double NOT NULL,
  `product_qty` int(2) NOT NULL,
  PRIMARY KEY (`order_detail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_detail_id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_qty`) VALUES
(1, 1, 1, 'Gallexy Y', 14500, 2),
(2, 1, 6, 'nokia', 5000, 1),
(3, 1, 8, 'Dell PC', 25000, 1),
(4, 2, 8, 'Dell PC', 25000, 2),
(5, 2, 9, 'Sony Bravia', 80000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pages`
--

CREATE TABLE IF NOT EXISTS `tbl_pages` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_pages`
--

INSERT INTO `tbl_pages` (`id`, `title`, `description`) VALUES
(1, 'Home', '<h4>\r\n	Our Training Services</h4>\r\n<p style="text-align:justify">\r\n	TalhaTraining is Bangladesh&#39;s <strong>leading it training provider</strong> of <strong>Mobile Applications</strong>, <strong>Web Development</strong>, <strong>Web Design</strong>, <strong>CMS</strong>, <strong>Microsoft Application</strong> and more <strong>it training courses</strong> for individuals and groups of Ten or more.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h4>\r\n	Online Training Courses</h4>\r\n<p style="text-align:justify">\r\n	TalhaTraining Introducing Exclusive <strong>Online Training Courses</strong> for the first time from Bangladesh. Our <strong>online courses</strong> help you to <strong>learn critical skills</strong>.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h4>\r\n	Unbeatable Quality &amp; Value</h4>\r\n<p style="text-align:justify">\r\n	TalhaTraining&#39;s <strong>high quality learning courses</strong> help you to achieve your <strong>training goals</strong> conveniently. These <strong>courses are a low-cost</strong> and are a perfect solution for individuals or small companies.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style="text-align:justify">\r\n	TalhaTraining&#39;s provides professional, training courses on a wide variety of subject for a <strong>full-year of access</strong> to all the courses in that series. Our instructors are in-demand, call today for more information or to schedule training.<strong> You provide the facility and we provide the rest!</strong></p>\r\n'),
(2, 'About', '<p>\r\n	This is About us Page.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `product_id` int(3) NOT NULL AUTO_INCREMENT,
  `category_id` int(2) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` float(10,2) NOT NULL,
  `product_quantity` int(3) NOT NULL,
  `product_description` text NOT NULL,
  `product_image` varchar(256) NOT NULL,
  `add_date` date NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `category_id`, `product_name`, `product_price`, `product_quantity`, `product_description`, `product_image`, `add_date`) VALUES
(1, 6, 'Gallexy Y', 14500.00, 50, '<p>\r\n	Android Phone</p>\r\n', 'microtablet.jpg', '2012-11-24'),
(2, 2, 'Sony Bravia', 90000.00, 30, '<p>\r\n	Sony TV</p>\r\n', 'tv7.jpg', '2012-11-14'),
(4, 4, 'iPhone 5', 78000.00, 10, '<p>\r\n	iPhone Mobile</p>\r\n', 'iphone.gif', '2012-11-14'),
(6, 6, 'nokia', 5000.00, 50, '<p>\r\n	Nokia Mobile</p>\r\n', 'nokia-n96-mobile-phone.jpg', '2012-12-14'),
(8, 0, 'Dell PC', 25000.00, 27, '<p>\r\n	This is Dell PC.</p>\r\n', 'ndesk.jpg', '2012-12-14'),
(9, 2, 'Sony Bravia', 80000.00, 9, '<p>\r\n	This is Sony TV.</p>\r\n', 'tv9.jpg', '2012-12-14'),
(10, 6, 'Asus', 35000.00, 15, '<p>\r\n	This is Asus Laptop,.</p>\r\n', 'asustablet.jpg', '2012-12-14'),
(11, 2, 'Samsung TV', 30000.00, 10, '<p>\r\n	This is samsung TV</p>\r\n', 'tv5.jpg', '2012-12-14'),
(12, 2, 'Google TV', 37000.00, 19, '<p>\r\n	This is Google TV.</p>\r\n', 'tv8.jpg', '2012-12-14'),
(13, 2, 'LG Tv', 38000.00, 39, '<p>\r\n	This is LG TV.</p>\r\n', 'tv6.jpg', '2012-12-14'),
(14, 2, 'Sony Rangs', 20000.00, 12, '<p>\r\n	This is Sony Rangs tv.</p>\r\n', 'tv10.jpg', '2012-12-14'),
(15, 2, 'Walton', 15000.00, 30, '<p>\r\n	This is walton TV.</p>\r\n', 'tv2.png', '2012-12-14'),
(16, 6, 'Acer Laptop', 40000.00, 20, '<p>\r\n	This is Acer Laptop</p>\r\n', 'acer.jpg', '2012-12-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping_address`
--

CREATE TABLE IF NOT EXISTS `tbl_shipping_address` (
  `shipping_id` int(4) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `zip_code` varchar(4) NOT NULL,
  `cell_no` varchar(50) NOT NULL,
  PRIMARY KEY (`shipping_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_shipping_address`
--

INSERT INTO `tbl_shipping_address` (`shipping_id`, `user_id`, `first_name`, `last_name`, `address`, `city`, `country`, `zip_code`, `cell_no`) VALUES
(1, 3, 'Saahil', 'alam', 'mohammadpur', 'dhaak', 'BD', '1209', '01712742217'),
(2, 3, 'Shafiul', 'Alam', 'Mohammmadpur', 'Dhaka', 'BD', '1207', '01712742217');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_id` int(5) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `company` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `zip_code` varchar(4) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `first_name`, `last_name`, `email_address`, `password`, `address`, `company`, `city`, `country`, `zip_code`) VALUES
(1, 'Saahil', 'Alam', 'saahil@gmail.com', '111111', 'Dhaka', 'TalhaTraining', 'Dhaka', 'BD', '1207'),
(3, 'Md. Shafiul', 'Alam', 'topu1826@gmail.com', '111111', 'Dhaka', 'TalhaTraining', 'dhaka', 'BD', '1207'),
(4, 'Tania', 'Alam', 'tani@gmail.com', '222222', 'Dhaka', 'TalhaTraining', 'Dhaka', 'BD', '1207'),
(13, 'nehan', 'alam', 'nehan@yahoo.com', '123456', '', '', '', 'BD', '1234'),
(14, 'Alif', 'Ahmed', 'alif@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Dhaka', 'TalhaTraining', 'Dhaka', 'BD', '1207');
